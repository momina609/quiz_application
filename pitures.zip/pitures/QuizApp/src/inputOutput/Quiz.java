package inputOutput;
import javax.swing.*;
import java.awt.event.*;  
import javax.swing.JLabel;
import java.awt.*;
import java.util.Collections;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
class Quiz extends JFrame implements ActionListener{
	 JLabel qno;
	 JLabel question;
	 String questions[][]=new String [10][5];
		String answers[][]=new String [10][2];
		String useranswers[][]=new String[10][1];
		JRadioButton opt1,opt2,opt3,opt4;
		ButtonGroup groupoptions;
		public static int timer=15;
		public static int ans_given=0;
		public static int count=0;
		public static int score=0;
		public static int lifelineCount = 3;
		public static int totalQuestions = 10;
		JButton next,lifeline,submit;
		String name;
	Quiz(String name)
	{
		this.name=name;
		setSize(1000,650);
		setLocation(150,0);
		setTitle("Quiz");
		getContentPane().setBackground(new Color(240, 248, 255));
	setLayout(null);
	ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/quiz.jpg"));
	JLabel image=new JLabel(i1);
	image.setBounds(0,0,1000,380);
	add(image);
	setVisible(true);
	qno=new JLabel();
	qno.setBounds(10,220,1000,380);
	qno.setFont(new Font("Times New Roman",Font.PLAIN,19));
	add(qno);
	question=new JLabel();
	question.setBounds(50,220,1000,380);
	question.setFont(new Font("Times New Roman",Font.PLAIN,18));
	add(question);
	questions[0][0]="Which concept focuses on hiding an object's internal state and requiring interaction through its methods?";
	questions[0][1]="Inheritance";
    questions[0][2]="Polymorphism";
    questions[0][3]="Abstraction";
    questions[0][4]="Encapsulation";
    questions[1][0]="Which is used to find and fix bugs in the java program?";
	questions[1][1]="JVM";
    questions[1][2]="JDB";
    questions[1][3]="JDK";
    questions[1][4]="JRE";
    questions[2][0]="What is the primary benefit of using inheritance in Java?";
	questions[2][1]="To create a new object";
    questions[2][2]="To increase code reusability";
    questions[2][3]="To hide data";
    questions[2][4]="To improve performance";
    questions[3][0]="Which of the following best describes polymorphism?";
	questions[3][1]="The ability of a class to inherit properties from multiple classes";
    questions[3][2]=" The ability to override methods in the same class";
    questions[3][3]="The process of hiding the implementation details of a class";
    questions[3][4]="The ability of different classes to be treated as instances of the same class";
    questions[4][0]="Which of the following is an example of abstraction in Java?";
	questions[4][1]="Using private variables in a class";
    questions[4][2]="Creating an abstract class with abstract methods";
    questions[4][3]="Overriding methods in a subclass";
    questions[4][4]="Implementing an interface";
    questions[5][0]="If class A is a subclass of class B, what can be said about class B?";
	questions[5][1]="Class B is a subclass of class A";
    questions[5][2]="Class B is a superclass of class A";
    questions[5][3]="Class B cannot be instantiated";
    questions[5][4]="Class B must be abstract";
    questions[6][0]="What keyword is used to define an abstract class in Java?";
	questions[6][1]="abstract";
    questions[6][2]="interface";
    questions[6][3]="extends";
    questions[6][4]=" super";
    questions[7][0]="What happens if a method in a subclass has the same name and parameters as a method in its superclass?";
   	questions[7][1]="The subclass method will not compile";
    questions[7][2]="The superclass method will be called";
    questions[7][3]="The subclass method will override the superclass method";
    questions[7][4]="Both methods will be called sequentially";
    questions[8][0]="Which access modifier allows the highest level of encapsulation in Java?";
   	questions[8][1]="public";
    questions[8][2]="protected";
    questions[8][3]="private";
    questions[8][4]="default";
    questions[9][0]="Which of the following is true about interfaces in Java?";
   	questions[9][1]="An interface can have both abstract methods and concrete methods.";
    questions[9][2]="A class can implement multiple interfaces.";
    questions[9][3]="An interface can be instantiated like a class";
    questions[9][4]="An interface can extend a class";
    answers[0][1]="Encapsulation";
    answers[1][1]="JDB";
    answers[2][1]="To increase code reusability";
    answers[3][1]="The ability of different classes to be treated as instances of the same class";
	answers[4][1]="Creating an abstract class with abstract methods";
    answers[5][1]="Class B is a superclass of class A";
    answers[6][1]="abstract";
    answers[7][1]="The subclass method will override the superclass method";
   	answers[8][1]="private";
   	answers[9][1]="A class can implement multiple interfaces.";
   	List<QuestionAnswerPair> combinedList = new ArrayList<>();
    for (int i = 0; i < questions.length; i++) {
        combinedList.add(new QuestionAnswerPair(questions[i], answers[i][1]));
    }
    // Shuffle the combined list
    Collections.shuffle(combinedList);

    // Split the combined structure back into separate arrays
    for (int i = 0; i < combinedList.size(); i++) {
        QuestionAnswerPair pair = combinedList.get(i);
        questions[i] = pair.question;
        answers[i][1] = pair.answer;
    }
	opt1=new JRadioButton();
	opt1.setBounds(20,420,700,30);
	opt1.setBackground(new Color(240, 248, 255));
	opt1.setFont(new Font("Dialog",Font.PLAIN,16));
	add(opt1);
	opt2=new JRadioButton();
	opt2.setBounds(20,450,700,30);
	opt2.setBackground(new Color(240, 248, 255));
	opt2.setFont(new Font("Dialog",Font.PLAIN,16));
	add(opt2);
	opt3=new JRadioButton();
	opt3.setBounds(20,480,700,30);
	opt3.setBackground(new Color(240, 248, 255));
	opt3.setFont(new Font("Dialog",Font.PLAIN,16));
	add(opt3);
	opt4=new JRadioButton();
	opt4.setBounds(20,510,700,30);
	opt4.setBackground(new Color(240, 248, 255));
	opt4.setFont(new Font("Dialog",Font.PLAIN,16));
	add(opt4);
	groupoptions=new ButtonGroup();
	groupoptions.add(opt1);
	groupoptions.add(opt2);
	groupoptions.add(opt3);
	groupoptions.add(opt4);
	 next=new JButton("Next");
	next.setBounds(800,430,150,30);
	next.setBackground(new Color(0,102,204));
	next.setForeground(Color.WHITE);
	next.setFont(new Font("Tahoma",Font.PLAIN,18));
	next.addActionListener(this);
	add(next);
	lifeline=new JButton("50-50 Lifeline");
	lifeline.setBounds(800,530,150,30);
	lifeline.setBackground(new Color(0,102,204));
	lifeline.setForeground(Color.WHITE);
	lifeline.setFont(new Font("Tahoma",Font.PLAIN,17));
	lifeline.addActionListener(this);
	add(lifeline);
	submit=new JButton("Submit");
	submit.setBounds(800,480,150,30);
	submit.setBackground(new Color(0,102,204));
	submit.setForeground(Color.WHITE);
	submit.setFont(new Font("Tahoma",Font.PLAIN,18));
	submit.setEnabled(false);
	submit.addActionListener(this);
	add(submit);
	start(count);
	setVisible(true);}
	public void actionPerformed(ActionEvent ae)
	{if(ae.getSource()==next)
	{
	repaint();
	opt1.setEnabled(true);
	opt2.setEnabled(true);
	opt3.setEnabled(true);
	opt4.setEnabled(true);
	ans_given=1;
	if(groupoptions.getSelection()==null)
	{
		useranswers[count][0]="";
		
	}else
	{
		useranswers[count][0]=groupoptions.getSelection().getActionCommand();
	}
	if(count==8)
	{
		next.setEnabled(false);
		submit.setEnabled(true);
	}
	
	
	
	count++;
	start(count);}
	else if(ae.getSource() == lifeline) {
	    if(lifelineCount > 0) {
	        lifelineCount--;

	        int correctOptionIndex = -1;

	        // Find the correct option index
	        for (int i = 1; i <= 4; i++) {
	            if (questions[count][i].equals(answers[count][1])) {
	                correctOptionIndex = i;
	                break;
	            }
	        }

	        // List of incorrect options
	        List<Integer> incorrectOptions = new ArrayList<>();
	        for (int i = 1; i <= 4; i++) {
	            if (i != correctOptionIndex) {
	                incorrectOptions.add(i);
	            }
	        }

	        // Shuffle the list of incorrect options to randomize the selection
	        Collections.shuffle(incorrectOptions);

	        // Disable two incorrect options
	        for (int i = 0; i < 2; i++) {
	            int optionToDisable = incorrectOptions.get(i);

	            if (optionToDisable == 1) {
	                opt1.setEnabled(false);
	            } else if (optionToDisable == 2) {
	                opt2.setEnabled(false);
	            } else if (optionToDisable == 3) {
	                opt3.setEnabled(false);
	            } else if (optionToDisable == 4) {
	                opt4.setEnabled(false);
	            }
	        }

	        // Notify user of remaining lifelines
	        JOptionPane.showMessageDialog(null, "Lifeline used! Remaining lifelines: " + lifelineCount);
	    } else {
	        // No lifelines remaining
	        JOptionPane.showMessageDialog(null, "No lifelines remaining!");
	    }
	}

        	
		
	
	
	 if(ae.getSource()==submit)
	{ans_given=1;
		 if(groupoptions.getSelection()==null)
			{
				useranswers[count][0]="";
				
			}else
			{
				useranswers[count][0]=groupoptions.getSelection().getActionCommand();
			}
			for(int i=0;i<useranswers.length;i++)
			{
				if(useranswers[i][0].equals(answers[i][1]))
				{
					score+=1;
					
				}
			}
				
			setVisible(false)	;
			new Score(name,score);
		
		
	}
	
	}
	
	
		public void paint(Graphics g)
	{super.paint(g);
	String time="Time left "+timer+" seconds";
	g.setColor(Color.RED);
	g.setFont(new Font("SansSerif",Font.BOLD,13));
	if(timer>0)
	{g.drawString(time, 840,440 );}
	else
	{
		g.drawString("Times up!!", 840,440 );
	}
	timer--;
	try {
		Thread.sleep(1000);
		repaint();
	}
	catch(Exception e)
	{e.printStackTrace();
	}
	if(ans_given==1)
	{ans_given=0;
	timer=15;}
	else if(timer<0)
	{
		timer=15;
		opt1.setEnabled(true);
		opt2.setEnabled(true);
		opt3.setEnabled(true);
		opt4.setEnabled(true);
		if(count==8)
		{
			next.setEnabled(false);
			submit.setEnabled(true);
		}
		if(count==9)
		{if(groupoptions.getSelection()==null)
		{
			useranswers[count][0]="";
			
		}else
		{
			useranswers[count][0]=groupoptions.getSelection().getActionCommand();
		}
		for(int i=0;i<useranswers.length;i++)
		{
			if(useranswers[i][0].equals(answers[i][1]))
			{
				score+=1;
			}
		}
			
		setVisible(false)	;
		new Score(name,score);
			
		}
		else
		{
		if(groupoptions.getSelection()==null)
		{
			useranswers[count][0]="";
			
		}else
		{
			useranswers[count][0]=groupoptions.getSelection().getActionCommand();
		}
		count++;
		start(count);}
	}
	}
	public void start(int count)
	{qno.setText("" + (count + 1) +".");
	question.setText(questions[count][0]);
	opt1.setText(questions[count][1]);
	opt1.setActionCommand(questions[count][1]);
	opt2.setText(questions[count][2]);
	opt2.setActionCommand(questions[count][2]);
	opt3.setText(questions[count][3]);
	opt3.setActionCommand(questions[count][3]);
	opt4.setText(questions[count][4]);
	opt4.setActionCommand(questions[count][4]);
	groupoptions.clearSelection();
	
	}
	public static void main(String[] args) {
		new Quiz("User");

	}
	

}
