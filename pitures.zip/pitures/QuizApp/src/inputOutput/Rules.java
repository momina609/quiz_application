package inputOutput;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Rules extends JFrame implements ActionListener{
	String name;
	JButton back,start;
	Rules(String name)
	{this.name=name;
	getContentPane().setBackground(new Color(240, 248, 255));
	setLayout(null)	;
	setVisible(true);
	setSize(1000,500);
	setLocation(120,120);
	setTitle("Rules");
	JLabel heading=new JLabel("Welcome "+name+" to Simple Minds");
	heading.setBounds(310,10,600,45);
	heading.setFont(new Font("SansSerif",Font.BOLD,25));
	heading.setForeground(new Color(0,102,204));
	add(heading);
	JLabel rules=new JLabel();
	rules.setBounds(20,20,700,350);
	rules.setFont(new Font("Tahoma",Font.PLAIN,15));
	add(rules);
	back=new JButton("Back");
	back.setBounds(350,370,100,30);
	back.setBackground(new Color(0,102,204));
	back.setFont(new Font("SansSerif", Font.BOLD, 16));
	back.setForeground(Color.WHITE);
	back.addActionListener(this);
	back.addMouseListener(new MouseAdapter() {
        public void mouseEntered(MouseEvent e) {
            back.setBackground(new Color(128,0,128)); 
        }
        public void mouseExited(MouseEvent e) {
            back.setBackground(new Color(0,102,204)); // Original color
        }
    });

	add(back);
	start=new JButton("START");
	start.setBounds(550,370,100,30);
	start.setBackground(new Color(0,102,204));
	start.setFont(new Font("SansSerif", Font.BOLD, 16));
	start.setForeground(Color.WHITE);
	start.addActionListener(this);
	start.addMouseListener(new MouseAdapter() {
        public void mouseEntered(MouseEvent e) {
            start.setBackground(new Color(128,0,128)); 
        }
        public void mouseExited(MouseEvent e) {
            start.setBackground(new Color(0,102,204)); // Original color
        }
    });
	
	add(start);
rules.setText(
			"<html>"+
			        "1.The quiz consists of a 10 questions."+"<br><br>"+
			       " 2.You have a total of 15 seconds to complete one question."+"<br><br>"+
			        "3.Each question has multiple-choice answers."+"<br><br>"+
			        "4.Choose the best answer for each question."+"<br><br>"+
			       " 5.Once you submit your answers, you cannot go back to change them."+"<br><br>"+
			        "6.There are 3 lifelines in the Quiz you have a choice to use them in any question."+"<br><br>"+
			       " 7.Each question carry one mark and total marks for quiz are 10."+"<br><br>"+
			        "8.No external resources are allowed during the quiz.."
			        +       
			"<html>"	);
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==start)
			
		{ setVisible(false);
			new Quiz(name);}
		else
		{setVisible(false);
		new Login();
		}
	}
public static void main(String[]args)
{new Rules("Momina");}
}
