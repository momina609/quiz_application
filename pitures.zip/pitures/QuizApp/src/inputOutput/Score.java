package inputOutput;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Score extends JFrame implements ActionListener {
	Score(String name,int score)
	{
		setSize(1000,650);
		setLocation(150,0);
		setTitle("Score");
		getContentPane().setBackground(new Color(240, 248, 255));
		setLayout(null);
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/score.png"));
		Image i2=i1.getImage().getScaledInstance(300, 250,Image.SCALE_DEFAULT);
		ImageIcon i3=new ImageIcon(i2);
		JLabel image=new JLabel(i3);
		image.setBounds(0,50,500,500);
		add(image);
		JLabel complete=new JLabel("Quiz Completed!");
		complete.setBounds(390,5,700,100);
		complete.setFont(new Font("Comic Sans MS",Font.BOLD,27));
		complete.setForeground(new Color(128,0,128));
		add(complete);
		JLabel heading=new JLabel("Thanks you! "+name+" for playing Simple Minds" );
		heading.setBounds(250,70,700,100);
		heading.setFont(new Font("Comic Sans MS",Font.BOLD,27));
		heading.setForeground(new Color(128,0,128));
		add(heading);
		JLabel ques=new JLabel("Total Questions: 10" );
		ques.setBounds(630,180,700,100);
		ques.setFont(new Font("Comic Sans MS",Font.PLAIN,27));
		ques.setForeground(new Color(0,102,204));
		add(ques);
		JLabel ans=new JLabel("Corrected answers: "+score );
		ans.setBounds(630,220,700,100);
		ans.setFont(new Font("Comic Sans MS",Font.PLAIN,27));
		ans.setForeground(new Color(0,102,204));
		add(ans);
		setVisible(true);
		JLabel sCore=new JLabel( "Your score is: "+score+" out of 10");
		sCore.setBounds(600,300,400,30);
		sCore.setFont(new Font("Comic Sans MS",Font.PLAIN,26));
		sCore.setForeground(new Color(0,102,204));
		add(sCore);
		JLabel statusLabel = new JLabel();
        statusLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
       statusLabel.setForeground(new Color(128,0,128));
        statusLabel.setBounds(580,340, 400, 50);
        // Logic to determine status based on score
        if (score < 5) {
            statusLabel.setText("Don't worry! Keep practicing.");
        } else if (score >= 5 && score <= 7) {
            statusLabel.setText("Good Job! You're Improving.");
        } else if (score >= 8 && score <= 10) {
            statusLabel.setText("Well done! You're a genius");
        }
         add(statusLabel);
		setVisible(true);
		JButton exitButton = new JButton("Exit");
        exitButton.setFont(new Font("SansSerif", Font.BOLD, 16));
        exitButton.setBounds(700,400,120,30);
        exitButton.setBackground(new Color(0,102,204));
        exitButton.setForeground(Color.WHITE);
        exitButton.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                exitButton.setBackground(new Color(128,0,128)); 
            }
            public void mouseExited(MouseEvent e) {
                exitButton.setBackground(new Color(0,102,204)); // Original color
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        add(exitButton);
	}
	public static void main(String[] args) {
		new Score("User",0);}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}}