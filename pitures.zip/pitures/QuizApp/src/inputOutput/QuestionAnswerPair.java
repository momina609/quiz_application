package inputOutput;

public class QuestionAnswerPair {
	 String[] question;
	    String answer;

	    QuestionAnswerPair(String[] question, String answer) {
	        this.question = question;
	        this.answer = answer;
	    }
}
