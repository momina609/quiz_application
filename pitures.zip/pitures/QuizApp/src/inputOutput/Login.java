package inputOutput;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
	public class Login extends JFrame implements ActionListener {
	    JButton rules, back;
	    JTextField tfname;
	     Login() {
	        // Frame settings
	        getContentPane().setBackground(new Color(245, 245, 245)); // Light gray background
	        setLayout(null);
	         // Background image
	        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/login.jpeg"));
	        JLabel image = new JLabel(i1);
	        image.setBounds(0, 0, 600, 500);
	        add(image);
	        // Heading
	        JLabel heading = new JLabel("Simple Minds");
	        heading.setBounds(700, 60, 300, 45);
	        heading.setFont(new Font("SansSerif", Font.BOLD, 36));
	        heading.setForeground(new Color(0, 102, 204));
	        add(heading);

	        // Name label
	        JLabel name = new JLabel("Enter your name:");
	        name.setBounds(730, 150, 300, 20);
	        name.setFont(new Font("SansSerif", Font.BOLD, 18));
	        name.setForeground(new Color(0, 102, 204));
	        add(name);

	        // Name input
	        tfname = new JTextField();
	        tfname.setBounds(650, 200, 300, 35);
	        tfname.setFont(new Font("SansSerif", Font.PLAIN, 18));
	        tfname.setBorder(BorderFactory.createLineBorder(new Color(0, 102, 204), 2));
	        add(tfname);

	        // Rules button
	        rules = new JButton("Rules");
	        rules.setBounds(650, 270, 120, 35);
	        rules.setBackground(new Color(0, 102, 204));
	        rules.setForeground(Color.WHITE);
	        rules.setFont(new Font("SansSerif", Font.BOLD, 16));
	        rules.setCursor(new Cursor(Cursor.HAND_CURSOR));
	        rules.addActionListener(this);
	        rules.addMouseListener(new MouseAdapter() {
	            public void mouseEntered(MouseEvent e) {
	                rules.setBackground(new Color(128,0,128)); 
	            }
	            public void mouseExited(MouseEvent e) {
	                rules.setBackground(new Color(0,102,204)); // Original color
	            }
	        });
	        add(rules);

	        // Back button
	        back = new JButton("Back");
	        back.setBounds(830, 270, 120, 35);
	        back.setBackground(new Color(0, 102, 204));
	        back.setForeground(Color.WHITE);
	        back.setFont(new Font("SansSerif", Font.BOLD, 16));
	        back.setCursor(new Cursor(Cursor.HAND_CURSOR));
	        back.addActionListener(this);
	        back.addMouseListener(new MouseAdapter() {
	            public void mouseEntered(MouseEvent e) {
	                back.setBackground(new Color(128,0,128)); 
	            }
	            public void mouseExited(MouseEvent e) {
	                back.setBackground(new Color(0,102,204)); // Original color
	            }
	        });
	        add(back);

	        // Frame settings
	        setSize(1000, 500);
	        setVisible(true);
	        setLocation(120, 120);
	        setResizable(false);
	        setTitle("Login");
	    }

	    public void actionPerformed(ActionEvent ae) {
	        if (ae.getSource() == rules) {
	            String name = tfname.getText();
	            if (name.isEmpty()) {
	                JOptionPane.showMessageDialog(this, "Name cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
	            } else {
	                new Rules(name);
	            }
	        } else if (ae.getSource() == back) {
	            setVisible(false);
	        }
	    }

	    public static void main(String[] args) {
	        new Login();
	    }
	}



